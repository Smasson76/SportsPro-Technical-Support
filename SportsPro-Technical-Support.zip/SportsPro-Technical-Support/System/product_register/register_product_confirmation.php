<?php include '../view/header.php'; ?>
<main>

<!-- User search for customer -->
<h1>Register Product</h1><br>
    <label>Product <?php echo('('); echo $product_name; echo(')'); ?> was registered succesfully.</label>
</main>
<?php include '../view/footer.php'; ?>